import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'

dotenv.config()

const app = express()

import database from './src/config/mysql.config.js'

// Test MySQL connection
database.query('SELECT 1 + 1 AS result')
    .then(() => console.log('Connected to MySQL'))
    .catch((err) => console.error('MySQL connection error:', err))

// Middlewares
app.use(cors())
app.use(express.json())

// Routes
app.get('/', (req, res) => {
    res.send('Backend is running!')
})

import userModel from './src/models/user.model.js'
const { createUserTable, createUser, findUserByEmail } = userModel

// Initialize database table
createUserTable().then(() => {
    console.log('User table is ready');
}).catch((err) => {
    console.error('Error initializing database:', err);
});

import userRoutes from './src/routes/user.routes.js'

app.use(userRoutes);



const PORT = process.env.PORT || 3000

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`)
})
