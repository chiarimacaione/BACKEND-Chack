import { ENVIROMENT } from './enviroment.js'
import dotenv from 'dotenv'
import mysql from 'mysql2/promise'

const db = mysql.createPool({
    host: ENVIROMENT.MYSQL.DB_HOST,
    user: ENVIROMENT.MYSQL.DB_USER,
    password: ENVIROMENT.MYSQL.DB_PASSWORD,
    database: ENVIROMENT.MYSQL.DB_NAME,
    port: ENVIROMENT.MYSQL.DB_PORT
});

(async () => {
    try {
        await db.getConnection();
        console.log('Connected to Clever Cloud MySQL');
    } catch (error) {
        console.error('Database connection failed:', error);
        process.exit(1); // Salir si la conexión falla
    }
})();

export default db