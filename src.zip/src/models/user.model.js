import bcrypt from 'bcrypt'
import db from '../config/mysql.config.js'

// User table
const createUserTable = async () => {
    const query = `
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    `
    await db.query(query);
}

// Hash password
const hashPassword = async (password) => {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
}

// Create a new user
const createUser = async (name, email, password) => {
    const hashedPassword = await hashPassword(password);
    const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)'
    return db.query(query, [name, email, hashedPassword])
}

// Find user by email
const findUserByEmail = async (email) => {
    const query = 'SELECT * FROM users WHERE email = ?';
    const [rows] = await db.query(query, [email]);
    return rows[0];
}

export default { createUserTable, createUser, findUserByEmail }