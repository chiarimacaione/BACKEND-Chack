import express from 'express'

import userModel from '../models/user.model.js';
const { createUserTable, createUser, findUserByEmail } = userModel;


const router = express.Router()

router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;
    await createUser(name, email, password);
    res.status(201).send('User created');
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    await createUser( email, password);
    res.status(201).send('User created');
});

// Exportar las rutas como default
export default router
